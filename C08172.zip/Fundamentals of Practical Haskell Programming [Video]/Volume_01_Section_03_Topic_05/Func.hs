------------------------------------------------------------
--
-- Func.hs
-- Code sample accompanying topic 1.3.5 "Pattern matching"
-- See README.md for details
--
-- Fundamentals of Practical Haskell Programming
-- By Richard Cook
--
------------------------------------------------------------

func x y z = x + y + z

main = print $ func 1 2 3
